      <!-- Favicon -->
      <link rel="shortcut icon" href="<?php echo e(asset('backend/asset/images/logo1.png')); ?>" />
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('backend/asset/css/bootstrap.min.css')); ?>">
      <!-- Typography CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('backend/asset/css/typography.css')); ?>">
      <!-- Style CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('backend/asset/css/style.css')); ?>">
      <!-- Responsive CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('backend/asset/css/responsive.css')); ?>">
      
      <link rel="stylesheet" href="<?php echo e(asset('backend/asset/css/dataTables.bootstrap4.min.css')); ?>">
      
      <link rel="stylesheet" href="<?php echo e(asset('backend/asset/css/toastr.min.css')); ?>">


      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/layouts/backend/includes/header.blade.php ENDPATH**/ ?>