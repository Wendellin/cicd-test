<div class="modal fade" id="createNewDistrict" tabindex="-1" aria-labelledby="createNewDistrictLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="createNewDistrictLabel">Create New District</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?php echo e(route('admin.district-store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal-body text-start">

                <div class="form-group">
                    <label for="name">District Name</label>
                    <input type="name" class="form-control" id="name" name="name" required>
                 </div>

                 <div class="form-group">
                    <label for="name">Province Name</label>
                    <select name="province_id" id="province_id" class="form-control">
                        <option selected disabled>-- Select Province --</option>

                        <?php $__empty_1 = true; $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($province->id); ?>"><?php echo e($province->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option disabled>No Province Available</option>
                        <?php endif; ?>
                    </select>
                 </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
<?php /**PATH /var/www/html/resources/views/admin/district/create.blade.php ENDPATH**/ ?>