<?php $__env->startSection('title', 'HOME'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
       <div class="col-lg-4">
          <div class="iq-card">
             <div class="iq-card-body pl-0 pr-0 pt-0">
                <div class="doctor-details-block">
                   <div class="doc-profile-bg bg-primary" style="height:150px;">
                   </div>
                   <div class="doctor-profile text-center">
                      <img src="<?php echo e(asset('backend/asset/images/user/11.png')); ?>" alt="profile-img" class="avatar-130 img-fluid">
                   </div>
                   <div class="text-center mt-3 pl-3 pr-3">
                      <h4><b><?php echo e(Str::title($doctor->users->name)); ?></b></h4>
                      <p><?php echo e($doctor->users->roles->name); ?></p>
                      <p class="mb-0"><?php echo e($doctor->users->about); ?></p>
                   </div>
                   <hr>
                   <ul class="doctoe-sedual d-flex align-items-center justify-content-between p-0 m-0">
                      <li class="text-center">
                         <h3 class="counter">4500</h3>
                         <span>Operations</span>
                       </li>
                       <li class="text-center">
                         <h3 class="counter">100</h3>
                         <span>Hospital</span>
                       </li>
                       <li class="text-center">
                         <h3 class="counter">10000</h3>
                         <span>Patients</span>
                       </li>
                   </ul>
                </div>
             </div>
          </div>
          <div class="iq-card">
             <div class="iq-card-header d-flex justify-content-between">
                <div class="iq-header-title">
                   <h4 class="card-title">Personal Information</h4>
                </div>
             </div>
             <div class="iq-card-body">
                <div class="about-info m-0 p-0">
                   <div class="row">
                      <div class="col-4">Name:</div>
                      <div class="col-8"><?php echo e(Str::title($doctor->users->name)); ?></div>
                      <div class="col-4">Age:</div>
                      <div class="col-8"><?php echo e(date('Y') - (date('Y', strtotime($doctor->dob)))); ?> Years</div>
                      <div class="col-4">Role:</div>
                      <div class="col-8"><?php echo e($doctor->users->roles->name); ?></div>
                      <div class="col-4">Email:</div>
                      <div class="col-8"><a href="mailto:<?php echo e($doctor->users->email); ?>"> <?php echo e($doctor->users->email); ?> </a></div>
                      <div class="col-4">Phone:</div>
                      <div class="col-8"><a href="tel:<?php echo e($doctor->phone_no); ?>"><?php echo e($doctor->phone_no); ?></a></div>
                      <div class="col-4">Department:</div>
                      <div class="col-8"><?php echo e($doctor->departments->name); ?></div>
                   </div>
                </div>
             </div>
          </div>

       </div>
       <div class="col-lg-8">
          <div class="row">







            <div class="iq-card iq-card-block iq-card-stretch iq-card-height">
                <div class="iq-card-header d-flex justify-content-between">
                   <div class="iq-header-title">
                      <h4 class="card-title"><span class="fw-bold"><?php echo e(Str::title($doctor->users->name)); ?></span> Appointments</h4>
                   </div>
                </div>
                <div class="iq-card-body">
                   <div class="table-responsive">
                      <table class="table mb-0 table-borderless table-striped">
                         <thead>
                            <tr>
                               <th scope="col">ID</th>
                               <th scope="col">Patient Name </th>
                               <th scope="col">Patient Phone</th>
                               <th scope="col">Date</th>
                               <th scope="col">Status</th>
                               <th scope="col">Closed By</th>
                            </tr>
                         </thead>
                         <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($appointment->patients->users->name); ?></td>
                                    <td><?php echo e($appointment->patients->phone_no); ?></td>
                                    <td><?php echo e(date('D d M, Y', strtotime($appointment->date))); ?></td>
                                    <td>
                                        <?php if($appointment->status == 0): ?>
                                            <span class="badge text-bg-primary">Closed </span>
                                        <?php elseif($appointment->status == 2): ?>
                                            <span class="badge text-bg-success">Assigned </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($appointment->lastUpdatedBys->name); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>
                         </tbody>
                         <tfoot>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Patient Name </th>
                                <th scope="col">Patient Phone</th>
                                <th scope="col">Date</th>
                                <th scope="col">Status</th>
                                <th scope="col">Closed By</th>
                             </tr>
                         </tfoot>
                      </table>
                   </div>

                </div>
                <div class="text-end">
                    <?php echo $appointments->links(); ?>

                </div>
              </div>
            </div>
       </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/admin/doctor/show.blade.php ENDPATH**/ ?>