<?php $__env->startSection('title', 'Doctors'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
       <div class="col-sm-12">
          <div class="iq-card">
             <div class="iq-card-header justify-content-between">
                <div class="row pt-3">
                    <div class="col-sm-6">
                        <div class="iq-header-title">
                            <h4 class="card-title">Doctors</h4>
                         </div>
                    </div>
                    <div class="col-sm-6 text-end">
                        <a href="<?php echo e(route('admin.doctors.create')); ?>" class="btn btn-primary float-end">
                            <i class="fa-solid fa-plus"></i> New Doctor
                        </a>
                    </div>
                </div>
             </div>
             <div class="iq-card-body">
                <p>Images in Bootstrap are made responsive with <code>.img-fluid</code>. <code>max-width: 100%;</code> and <code>height: auto;</code> are applied to the image so that it scales with the parent element.</p>
                <div class="table-responsive">
                   <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                         <tr>
                            <th>ID</th>
                            <th>NAME</th>
                            <th>EMAIL</th>
                            <th>ROLE</th>
                            <th>PHONE NUMBER</th>
                            <th>ALT PHONE NUMBER</th>
                            <th>HOME ADDRESS</th>
                            <th>GENDER</th>
                            <th>ACTIONS</th>
                         </tr>
                      </thead>
                      <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e(Str::title($doctor->users->name)); ?></td>
                                    <td><a href="mailto:<?php echo e($doctor->users->email); ?>"><?php echo e($doctor->users->email); ?></a></td>
                                    <td><?php echo e($doctor->users->roles->name); ?> </td>
                                    <td><?php echo e($doctor->phone_no); ?></td>
                                    <td><?php echo e($doctor->alt_phone_no); ?></td>
                                    <td><?php echo e($doctor->street_address); ?></td>
                                    <td><?php echo e($doctor->gender? 'Female' : 'Male'); ?></td>
                                    <td>
                                        <!-- Example single danger button -->
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Action</button>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="<?php echo e(route('admin.doctors.edit', $doctor->id)); ?>">Edit</a></li>
                                                <li><a class="dropdown-item" href="<?php echo e(route('admin.doctors.show', $doctor->id)); ?>">View</a></li>
                                                <li><a type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#changeRole-<?php echo e($doctor->users->id); ?>">Change Role</a></li>
                                            </ul>
                                        </div>
                                        <?php echo $__env->make('admin.doctor.change-role', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                            <?php endif; ?>
                      </tbody>
                      <tfoot>
                         <tr>
                            <th>ID</th>
                            <th>NAME</th>
                            <th>EMAIL</th>
                            <th>ROLE</th>
                            <th>PHONE NUMBER</th>
                            <th>ALT PHONE NUMBER</th>
                            <th>HOME ADDRESS</th>
                            <th>GENDER</th>
                            <th>ACTIONS</th>
                         </tr>
                      </tfoot>
                   </table>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/admin/doctor/index.blade.php ENDPATH**/ ?>