<?php $__env->startSection('title'); ?> <?php echo e(Auth::user()->name); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
       <div class="col-sm-12">
          <div class="iq-card">
             <div class="iq-card-header justify-content-between">
                <div class="row pt-3">
                    <div class="col-sm-6">
                        <div class="iq-header-title">
                            
                            <h4 class="card-title">Appointments (<?php echo e($appointments->count()); ?>)</h4>
                         </div>
                    </div>
                    <div class="col-sm-6 text-end">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#patientCreateAppointment-<?php echo e($patient->id); ?>">
                            <i class="fa-solid fa-plus"></i> New Appointnment
                        </button>
                        <?php echo $__env->make('patient.appointment.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
             </div>
             <div class="iq-card-body">
                <p>Images in Bootstrap are made responsive with <code>.img-fluid</code>. <code>max-width: 100%;</code> and <code>height: auto;</code> are applied to the image so that it scales with the parent element.</p>
                <div class="table-responsive">
                   <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                         <tr>
                            <th>ID</th>
                            <th>DATE</th>
                            <th>SESSION</th>
                            <th>DEPARTMENT</th>
                            <th>SERVED BY</th>
                            <th>STATUS</th>
                            <th>BOOKED BY</th>
                            <th>ACTION</th>
                         </tr>
                      </thead>
                      <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e(date('D M d, Y', strtotime($appointment->date))); ?></td>
                                    <td><?php echo e($appointment->apointmentTimes->name); ?></td>
                                    <td><?php echo e($appointment->departments->name); ?></td>
                                    <td>
                                        <?php if($appointment->status): ?>
                                            ---
                                        <?php else: ?>
                                            <?php echo e($appointment->lastUpdatedBys->name); ?>

                                        <?php endif; ?>
                                    </td>
                                    <th>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" id="appointmentstatus" <?php echo e($appointment->status?'':'checked'); ?> <?php if(true): echo 'disabled'; endif; ?>>
                                            <label class="form-check-label" for="appointmentstatus"><?php echo e($appointment->status?'Upcoming' : 'Closed'); ?></label>
                                          </div>
                                    </th>
                                    <td><?php echo e($appointment->users->name); ?></td>
                                    <td>
                                        <?php if($appointment->status): ?>
                                            <div class="btn-group" role="group">
                                                <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                ACTIONS
                                                </button>
                                                <ul class="dropdown-menu">
                                                    
                                                    <li><a role="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#editPatientAppointment-<?php echo e($appointment->id); ?>">Edit</a></li>
                                                </ul>
                                            </div>
                                            <?php echo $__env->make('patient.appointment.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-primary" <?php if(true): echo 'disabled'; endif; ?>>Closed</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                            <?php endif; ?>
                      </tbody>
                      <tfoot>
                         <tr>
                            <th>ID</th>
                            <th>DATE</th>
                            <th>SESSION</th>
                            <th>DEPARTMENT</th>
                            <th>SERVED BY</th>
                            <th>STATUS</th>
                            <th>BOOKED BY</th>
                            <th>ACTION</th>
                         </tr>
                      </tfoot>
                   </table>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/patient/appointment/index.blade.php ENDPATH**/ ?>