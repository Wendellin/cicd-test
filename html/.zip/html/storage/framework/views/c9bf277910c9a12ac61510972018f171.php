<div class="iq-sidebar">
    <div class="iq-sidebar-logo d-flex justify-content-between">
       <a href="index.html">
       <img src="images/logo1.png" class="img-fluid" alt="">
       <span><?php echo e(config('app.name')); ?></span>
       </a>
       <div class="iq-menu-bt-sidebar">
             <div class="iq-menu-bt align-self-center">
                <div class="wrapper-menu">
                   <div class="main-circle"><i class="fa-solid fa-ellipsis"></i></div>
                   <div class="hover-circle"><i class="fa-solid fa-ellipsis fa-rotate-90"></i></div>
                </div>
             </div>
          </div>
    </div>
    <div id="sidebar-scrollbar">
       <nav class="iq-sidebar-menu">
          <ul id="iq-sidebar-toggle" class="iq-menu">

            
            <?php if(Request::is('admin*')): ?>
            
             <li class="iq-menu-title"><i class="ri-subtract-line"></i><span>Dashboard</span></li>
             <li class="<?php echo e(Route::is('admin.dashboard') ? 'active': ''); ?>">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="iq-waves-effect"><i class="fa-solid fa-house"></i><span> Home</span></a>
             </li>
             <li>
                <a href="<?php echo e(route('admin.appointment-sessions')); ?>" class="iq-waves-effect"><i class="fa-regular fa-clock"></i><span> Sessions </span></a>
             </li>
             <li>
                <a href="<?php echo e(route('admin.departments')); ?>" class="iq-waves-effect"><i class="fa-regular fa-building"></i><span> Departments </span></a>
             </li>
             <li>
                <a href="<?php echo e(route('admin.province')); ?>" class="iq-waves-effect"><i class="fa-solid fa-earth-africa"></i><span> Provinces </span></a>
             </li>
             <li>
                <a href="<?php echo e(route('admin.district')); ?>" class="iq-waves-effect"><i class="fa-solid fa-hippo"></i><span> Districts </span></a>
             </li>
             <li>
                <a href="<?php echo e(route('admin.doctors.index')); ?>" class="iq-waves-effect"><i class="fa-solid fa-user-doctor"></i><span> Doctor</span></a>
             </li>
             <li>
                <a href="<?php echo e(route('admin.patients.index')); ?>" class="iq-waves-effect"><i class="fa-solid fa-bed-pulse"></i><span> Patients</span></a>
             </li>
             <li>
                <a href="<?php echo e(route('admin.appointments.index')); ?>" class="iq-waves-effect"><i class="fa-solid fa-stopwatch"></i><span> Appointments</span></a>
             </li>
             <li>
                <a href="<?php echo e(route('admin.roles.index')); ?>" class="iq-waves-effect"><i class="fa-solid fa-hat-cowboy-side"></i><span> Roles</span></a>
             </li>
             <li>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="iq-waves-effect"><i class="fa-solid fa-user"></i><span> Users</span></a>
             </li>
             <?php endif; ?>
            


            
            <?php if(Request::is('doctor*')): ?>
            <li class="iq-menu-title"><i class="ri-subtract-line"></i><span>Dashboard</span></li>
             <li class="<?php echo e(Route::is('doctor.dashboard') ? 'active': ''); ?>">
                <a href="<?php echo e(route('doctor.dashboard')); ?>" class="iq-waves-effect"><i class="fa-solid fa-house"></i><span> Home</span></a>
             </li>
            <li>
                <a href="<?php echo e(route('doctor.appointments')); ?>" class="iq-waves-effect"><i class="fa-solid fa-stopwatch"></i><span>My Appointments</span></a>
             </li>
             <?php if(Auth::user()->role_id == 5): ?>
                <li>
                    <a href="<?php echo e(route('doctor.appointments.all')); ?>" class="iq-waves-effect"><i class="fa-solid fa-stopwatch"></i><span> All Appointment</span></a>
                </li>
             <?php endif; ?>
            <?php endif; ?>



            
            <?php if(Request::is('assistant*')): ?>
            <li class="iq-menu-title"><i class="ri-subtract-line"></i><span>Dashboard</span></li>
            <li class="<?php echo e(Route::is('assistant.dashboard') ? 'active': ''); ?>">
               <a href="<?php echo e(route('assistant.dashboard')); ?>" class="iq-waves-effect"><i class="fa-solid fa-house"></i><span> Home</span></a>
            </li>
           <li>
               <a href="<?php echo e(route('assistant.appointments.index')); ?>" class="iq-waves-effect"><i class="fa-solid fa-stopwatch"></i><span> Appointments</span></a>
            </li>
            <li>
                <a href="<?php echo e(route('assistant.patient.index')); ?>" class="iq-waves-effect"><i class="fa-solid fa-stopwatch"></i><span> Patients</span></a>
             </li>
            <?php endif; ?>


            
            <?php if(Request::is('patient*')): ?>
            <li class="iq-menu-title"><i class="ri-subtract-line"></i><span>Dashboard</span></li>
            <li class="<?php echo e(Route::is('patient.dashboard') ? 'active': ''); ?>">
               <a href="<?php echo e(route('assistant.dashboard')); ?>" class="iq-waves-effect"><i class="fa-solid fa-house"></i><span> Home</span></a>
            </li>
           <li>
               <a href="<?php echo e(route('patient.appointments.index')); ?>" class="iq-waves-effect"><i class="fa-solid fa-stopwatch"></i><span> Appointments</span></a>
            </li>
            <?php endif; ?>


             
            <li class="iq-menu-title"><i class="ri-subtract-line"></i><span>Communication</span></li>
            <li><a href="#" class="iq-waves-effect"><i class="fa-solid fa-comments"></i><span>Chat</span></a></li>

           <li>
             <a href="#mailbox" class="iq-waves-effect collapsed" data-toggle="collapse" aria-expanded="false">
                <i class="fa-solid fa-envelope"></i><span>Email</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
             <ul id="mailbox" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                <li><a href="#"><i class="ri-inbox-fill"></i>Inbox</a></li>
                <li><a href="#"><i class="ri-edit-2-fill"></i>Email Compose</a></li>
             </ul>
          </li>

          
            <li class="iq-menu-title"><i class="fa-solid fa-gears"></i><span>Settings</span></li>
            <li>
                <a href="
                    <?php if(Auth::user()->role_id == 1): ?>
                        <?php echo e(route('admin.profile')); ?>

                    <?php elseif(Auth::user()->role_id == 2 || Auth::user()->role_id == 5): ?>
                        <?php echo e(route('doctor.profile')); ?>

                    <?php elseif(Auth::user()->role_id == 3): ?>
                        <?php echo e(route('assistant.profile')); ?>

                    <?php else: ?>
                        <?php echo e(route('patient.profile')); ?>

                    <?php endif; ?>
                " class="iq-waves-effect">
                    <i class="fa-solid fa-user-nurse"></i>
                    <span>My Profile</span>
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('logout')); ?>"
                   class="iq-waves-effect"
                   onclick="event.preventDefault();
                   document.getElementById('logout-form').submit();"
                   role="button">
                    <i class="fa-solid fa-right-from-bracket"></i><span><?php echo e(__('Sign Out')); ?></span>
                </a>
            </li>
          </ul>
       </nav>
       <div class="p-3"></div>
    </div>
 </div>
<?php /**PATH /var/www/html/resources/views/layouts/backend/includes/sidebar.blade.php ENDPATH**/ ?>