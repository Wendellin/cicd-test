<footer class="bg-white iq-footer">
    <div class="container-fluid">
       <div class="row">
          <div class="col-lg-6">
             <ul class="list-inline mb-0">
                <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
                <li class="list-inline-item"><a href="#">Terms of Use</a></li>
             </ul>
          </div>
          <div class="col-lg-6 text-right">
             Copyright <?php echo e(date('Y')); ?> <a href="<?php echo e(route('welcome')); ?>"><?php echo e(config('app.name')); ?></a> All Rights Reserved.
          </div>
       </div>
    </div>
 </footer>
<?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/layouts/backend/includes/footer.blade.php ENDPATH**/ ?>