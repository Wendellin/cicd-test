<?php $__env->startSection('title', 'HOME'); ?>

<?php $__env->startSection('content'); ?>
    Welcome <?php echo e(Auth::user()->name); ?> as <?php echo e(Auth::user()->roles->name); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/home.blade.php ENDPATH**/ ?>