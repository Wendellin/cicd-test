<div class="modal fade" id="editRole-<?php echo e($role->id); ?>" tabindex="-1" aria-labelledby="editRoleLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="editRoleLabel">Edit Role</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?php echo e(route('admin.roles.update', $role->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="modal-body">

                <div class="form-group mb-3">
                    <label for="name">Role Name</label>
                    <input type="name" class="form-control" id="name" name="name" value="<?php echo e($role->name); ?>" required>
                 </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
<?php /**PATH /var/www/html/resources/views/admin/role/edit.blade.php ENDPATH**/ ?>