<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title><?php echo $__env->yieldContent('title'); ?> || Bombo Hosp</title>


    <?php echo $__env->make('layouts.backend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


   </head>
   <body>
      
      <!-- Wrapper Start -->
      <div class="wrapper">
         <!-- Sidebar  -->

         <?php echo $__env->make('layouts.backend.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

         <!-- Page Content  -->
         <div id="content-page" class="content-page">
            <!-- TOP Nav Bar -->
                <?php echo $__env->make('layouts.backend.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- TOP Nav Bar END -->


            <div class="container-fluid">
               <?php echo $__env->yieldContent('content'); ?>
            </div>


      <!-- Footer -->
        <?php echo $__env->make('layouts.backend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Footer END -->
         </div>
      </div>
      <!-- Wrapper END -->


      <?php echo $__env->make('layouts.backend.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   </body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/backend/index.blade.php ENDPATH**/ ?>