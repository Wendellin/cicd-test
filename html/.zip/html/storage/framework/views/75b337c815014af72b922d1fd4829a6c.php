<div class="modal fade" id="bookPatientAppointmentFromUser-<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="bookPatientAppointmentFromUserLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="bookPatientAppointmentFromUserLabel">Book Appointment for <?php echo e($user->name); ?></h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?php echo e(route('admin.appointments.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="patient_id" id="patient_id" value="<?php echo e($user->id); ?>">
            <div class="modal-body">
                <div class="form-group">
                    <label for="name" class="form-label mb-2">Appointment Date</label>
                    <input type="date" class="form-control" id="date" name="date" required>
                </div>

                <div class="row my-4">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="name" class="form-label mb-2">Session</label>
                            <select name="session" id="session" class="form-control">
                                <option selected <?php if(true): echo 'disabled'; endif; ?>>-- Select Session --</option>
                                <?php $__empty_1 = true; $__currentLoopData = $aTimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($aTime->id); ?>"><?php echo e($aTime->start_time); ?> - <?php echo e($aTime->end_time); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled>No Session Available</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="name" class="form-label mb-2">Department</label>
                            <select name="department" id="department" class="form-control">
                                <option selected <?php if(true): echo 'disabled'; endif; ?>>-- Select Department --</option>
                                <?php $__empty_1 = true; $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled>No Department Available</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
      </div>
    </div>
  </div>
<?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/admin/user/modal/book-appointment.blade.php ENDPATH**/ ?>