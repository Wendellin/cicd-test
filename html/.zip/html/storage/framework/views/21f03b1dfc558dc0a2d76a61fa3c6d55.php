<?php $__env->startSection('title', 'Patients'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
       <div class="col-sm-12">
          <div class="iq-card">
             <div class="iq-card-header justify-content-between">
                <div class="row pt-3">
                    <div class="col-sm-6">
                        <div class="iq-header-title">
                            <h4 class="card-title">Patients</h4>
                         </div>
                    </div>
                    <div class="col-sm-6 text-end">
                        <a href="<?php echo e(route('admin.patients.create')); ?>" class="btn btn-primary float-end">
                            <i class="fa-solid fa-plus"></i> New Patient
                        </a>
                    </div>
                </div>
             </div>
             <div class="iq-card-body">
                <p>Images in Bootstrap are made responsive with <code>.img-fluid</code>. <code>max-width: 100%;</code> and <code>height: auto;</code> are applied to the image so that it scales with the parent element.</p>
                <div class="table-responsive">
                   <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                         <tr>
                            <th>ID</th>
                            <th>NAME</th>
                            <th>EMAIL</th>
                            <th>PHONE NUMBER</th>
                            <th>ALT PHONE NO.</th>
                            <th>HOME ADDRESS</th>
                            <th>GENDER</th>
                            <th>ACTION</th>
                         </tr>
                      </thead>
                      <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e(Str::title($patient->users->name)); ?></td>
                                    <td><a href="mailto:<?php echo e($patient->users->email); ?>"><?php echo e($patient->users->email); ?></a></td>
                                    <td><?php echo e($patient->phone_no); ?></td>
                                    <td><?php echo e($patient->alt_phone_no); ?></td>
                                    <td><?php echo e($patient->street_address); ?></td>
                                    <td><?php echo e($patient->gender? 'Female' : 'Male'); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                              Actions
                                            </button>
                                            <ul class="dropdown-menu" style="">
                                              <li><a class="dropdown-item" href="<?php echo e(route('admin.patients.edit', $patient->id)); ?>"><i class="fa-solid fa-pen-to-square"></i> Edit</a></li>
                                              <li><a class="dropdown-item" href="<?php echo e(route('admin.patients.show', $patient->id)); ?>"><i class="fa-regular fa-eye"></i> View</a></li>
                                              <li><a class="dropdown-item" role="button" data-bs-toggle="modal" data-bs-target="#bookPatientAppointment-<?php echo e($patient->id); ?>"><i class="fa-solid fa-calendar-check"></i> Appointment</a></li>
                                            </ul>
                                          </div>
                                          <?php echo $__env->make('admin.appointment.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                            <?php endif; ?>
                      </tbody>
                      <tfoot>
                         <tr>
                            <th>ID</th>
                            <th>NAME</th>
                            <th>EMAIL</th>
                            <th>PHONE NUMBER</th>
                            <th>ALT PHONE NO.</th>
                            <th>HOME ADDRESS</th>
                            <th>GENDER</th>
                            <th>ACTION</th>
                         </tr>
                      </tfoot>
                   </table>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/admin/patient/index.blade.php ENDPATH**/ ?>