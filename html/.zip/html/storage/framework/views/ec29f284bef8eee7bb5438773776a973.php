<?php $__env->startSection('title'); ?> <?php echo e(Auth::user()->name); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
       <div class="col-sm-12">
          <div class="iq-card">
             <div class="iq-card-header justify-content-between">
                <div class="row pt-3">
                    <div class="col-sm-6">
                        <div class="iq-header-title">
                            
                            <h4 class="card-title"><?php echo e(Auth::user()->name); ?> Appointments [<?php echo e($appointments->count()); ?>]</h4>
                         </div>
                    </div>
                    <div class="col-sm-6 text-end">
                        <a href="<?php echo e(route('admin.appointments.create')); ?>" class="btn btn-primary">
                            <i class="fa-solid fa-plus"></i> New Appointnment
                        </a>
                    </div>
                </div>
             </div>
             <div class="iq-card-body">
                <p>Images in Bootstrap are made responsive with <code>.img-fluid</code>. <code>max-width: 100%;</code> and <code>height: auto;</code> are applied to the image so that it scales with the parent element.</p>
                <div class="table-responsive">
                   <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                         <tr>
                            <th>ID</th>
                            <th>DATE</th>
                            <th>SESSION</th>
                            <th>PATIENT NAME</th>
                            <th>DEPARTMENT</th>
                            <th>ASSIGNED TO</th>
                            
                            <th>BOOKED BY</th>
                            <th>ACTION</th>
                         </tr>
                      </thead>
                      <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e(date('D M d, Y', strtotime($appointment->date))); ?></td>
                                    <td><?php echo e($appointment->apointmentTimes->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('doctor.patient.profile', $appointment->patients->slug)); ?>">
                                            <?php echo e($appointment->patients->users->name); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($appointment->departments->name); ?></td>
                                    <td>
                                        <?php if($appointment->status == 0): ?>
                                            <span class="badge text-bg-success">Completed: <small><?php echo e($appointment->lastUpdatedBys->name); ?></small></span>
                                        <?php elseif($appointment->status == 1): ?>
                                            <span class="badge text-bg-primary">New, Upcoming</span>
                                        <?php else: ?>
                                            <span class="badge text-bg-danger">Assigned:
                                                <small>
                                                   <?php if(!(is_null($appointment->doctor_id))): ?>
                                                        <?php echo e($appointment->doctors->users->name); ?>

                                                   <?php endif; ?>
                                                </small>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td><?php echo e($appointment->users->name); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                              ACTIONS
                                            </button>
                                            <ul class="dropdown-menu">
                                              <li><a class="dropdown-item" href="<?php echo e(route('admin.appointments.edit', $appointment->id)); ?>" title="Edit Appointment">Edit</a></li>
                                              <li><a role="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#closeAppointment-<?php echo e($appointment->id); ?>">Close</a></li>
                                            </ul>
                                          </div>
                                          <?php echo $__env->make('admin.appointment.close', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                            <?php endif; ?>
                      </tbody>
                      <tfoot>
                         <tr>
                            <th>ID</th>
                            <th>DATE</th>
                            <th>SESSION</th>
                            <th>PATIENT NAME</th>
                            <th>DEPARTMENT</th>
                            <th>ASSIGNED TO</th>
                            
                            <th>BOOKED BY</th>
                            <th>ACTION</th>
                         </tr>
                      </tfoot>
                   </table>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/admin/appointment/index.blade.php ENDPATH**/ ?>