<?php $__env->startSection('title'); ?> <?php echo e($user->name); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

Show patient details

<strong><?php echo e($user->name); ?></strong>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/admin/user/show.blade.php ENDPATH**/ ?>