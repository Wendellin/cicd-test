<?php $__env->startSection('title', 'Verify Email'); ?>


<?php $__env->startSection('content'); ?>
<div class="col-md-6 position-relative">
    <div class="sign-in-from">
        <img src="images/login/mail.png" width="80" alt="">
        <h1 class="mt-3 mb-0">Success !</h1>
        <p>
            A email has been send to <strong><?php echo e(Auth::user()->email); ?></strong>.
            Please check for an email from the <?php echo e(config('app.name')); ?> and click on the included link to confirm your password.
        </p>
        <div class="d-inline-block w-100">

                <a href="<?php echo e(route('welcome')); ?>" class="btn btn-primary mt-3">Back to Home</a>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authentication.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/auth/verify.blade.php ENDPATH**/ ?>