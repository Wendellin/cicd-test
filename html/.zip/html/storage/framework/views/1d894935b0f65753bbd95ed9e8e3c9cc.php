
<div class="modal fade" id="changeRoleFromUser-<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="changeRoleFromUserLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="changeRoleFromUserLabel">Change Doctor's Role</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <p class="bg-primary"><strong>Current Role: </strong> <?php echo e($user->name); ?></p>
            <form action="<?php echo e(route('admin.change.doctor.role', $user->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="mb-3">
                    <label for="role" class="form-label">Email address</label>
                    <select name="role_id" id="role_id" class="form-select">
                        <option selected disabled>-- Select Role--</option>
                       <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <option disabled>-- No Role Selected --</option>
                       <?php endif; ?>
                    </select>
                  </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
    </form>
      </div>
    </div>
</div>
<?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/admin/user/modal/change-doctor-role.blade.php ENDPATH**/ ?>