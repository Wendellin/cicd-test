<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
       <div class="col-sm-12">
          <div class="iq-card">
             <div class="iq-card-header justify-content-between">
                <div class="row pt-3">
                    <div class="col-sm-6">
                        <div class="iq-header-title">
                            <h4 class="card-title">Users</h4>
                         </div>
                    </div>
                    <div class="col-sm-6 text-end">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-plus"></i> New </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.doctors.create')); ?>">Doctor</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.patients.create')); ?>">Patient</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.users.create')); ?>">Assistant</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="iq-card-body">
                <p>Images in Bootstrap are made responsive with <code>.img-fluid</code>. <code>max-width: 100%;</code> and <code>height: auto;</code> are applied to the image so that it scales with the parent element.</p>
                <div class="table-responsive">
                   <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                         <tr>
                            <th>ID</th>
                            <th>NAME</th>
                            <th>EMAIL</th>
                            <th>ROLE</th>
                            <th>CREATED AT</th>
                            <th>ACTIONS</th>
                         </tr>
                      </thead>
                      <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e(Str::title($user->name)); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <?php if($user->role_id == 1): ?>
                                            <span class="badge rounded-pill text-bg-danger"><?php echo e($user->roles->name); ?></span>
                                        <?php elseif($user->role_id == 2 || $user->role_id == 5): ?>
                                            <span class="badge rounded-pill text-bg-success"><?php echo e($user->roles->name); ?></span>
                                        <?php elseif($user->role_id == 3): ?>
                                            <span class="badge rounded-pill text-bg-info"><?php echo e($user->roles->name); ?></span>
                                        <?php else: ?>
                                            <span class="badge rounded-pill text-bg-primary"><?php echo e($user->roles->name); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($user->created_at->toFormattedDayDateString()); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-spinner fa-spin"></i> Actions </button>
                                            <ul class="dropdown-menu">
                                                    <?php if($user->role_id == 2 || $user->role_id == 5): ?>
                                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.doctors.edit', $user->doctors->id)); ?>">Edit</a></li>
                                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.doctors.show', $user->doctors->id)); ?>">View</a></li>
                                                        <li><a type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#changeRoleFromUser-<?php echo e($user->id); ?>">Change Role</a></li>
                                                    <?php elseif($user->role_id == 3): ?>
                                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.users.edit', $user->id)); ?>">Edit</a></li>
                                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.users.show', $user->id)); ?>">View</a></li>
                                                    <?php elseif($user->role_id == 4): ?>
                                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.patients.edit', $user->patients->id)); ?>"><i class="fa-solid fa-pen-to-square"></i> Edit</a></li>
                                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.patients.show', $user->patients->id)); ?>"><i class="fa-regular fa-eye"></i> View</a></li>
                                                        
                                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.appointments.create')); ?>"><i class="fa-solid fa-calendar-check"></i> Appointment</a></li>
                                                    <?php else: ?>
                                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa-solid fa-house-user fa-beat-fade"></i> Home</a></li>
                                                    <?php endif; ?>
                                            </ul>
                                        </div>
                                    </td>
                                    
                                    <?php echo $__env->make('admin.user.modal.change-doctor-role', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                      </tbody>
                      <tfoot>
                         <tr>
                            <th>ID</th>
                            <th>NAME</th>
                            <th>EMAIL</th>
                            <th>ROLE</th>
                            <th>CREATED AT</th>
                            <th>ACTIONS</th>
                         </tr>
                      </tfoot>
                   </table>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/user/index.blade.php ENDPATH**/ ?>