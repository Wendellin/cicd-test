<?php echo e($slot); ?>

<?php /**PATH /home/nahashon/Desktop/Projects/hms/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>