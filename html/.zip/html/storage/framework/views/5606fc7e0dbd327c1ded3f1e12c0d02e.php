<?php $__env->startSection('title'); ?>
    <?php echo e($appointment->patients->users->name); ?> Appointment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
       <div class="col-lg-3">
          <div class="iq-card">
             <div class="iq-card-header d-flex justify-content-between">
                <div class="iq-header-title">
                   <h4 class="card-title lh-lg"><span class="fw-bold"><?php echo e($appointment->patients->users->name); ?></span> <br> Appointment</h4>
                </div>
             </div>
          </div>
       </div>
       <div class="col-lg-9 mx-auto">
          <div class="iq-card">
             <div class="iq-card-header d-flex justify-content-between">
                <div class="iq-header-title">
                   <h4 class="card-title">Appointment Information</h4>
                </div>
             </div>
             <div class="iq-card-body">
                <div class="new-user-info">
                   <form action="<?php echo e(route('admin.appointments.update', $appointment->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                      <div class="row">
                        <div class="form-group mb-4 col-md-12">
                            <label for="patient_id">Patient Name</label>
                            <select name="patient_id" id="patient" class="form-select">
                                <option selected value="<?php echo e($appointment->patient_id); ?>"><?php echo e($appointment->patients->users->name); ?></option>
                                
                            </select>
                        </div>
                         <div class="form-group mb-4 col-md-6">
                            <label for="lname">Session Time</label>
                            <select name="session" id="session" class="form-select">
                                <option selected value="<?php echo e($appointment->appointment_time_id); ?>"><?php echo e($appointment->apointmentTimes->name); ?></option>
                                <option <?php if(true): echo 'disabled'; endif; ?>>___________________</option>
                                <?php $__empty_1 = true; $__currentLoopData = $aTimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($aTime->id); ?>"><?php echo e($aTime->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled>No Session Available</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="form-group mb-4 col-md-6">
                            <label for="lname">Department</label>
                            <select name="department" id="department" class="form-select">
                                <option selected value="<?php echo e($appointment->department_id); ?>"><?php echo e($appointment->departments->name); ?></option>
                                <option <?php if(true): echo 'disabled'; endif; ?>>___________________</option>
                                <?php $__empty_1 = true; $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled>No Department Available</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="form-group mb-4 col-md-12">
                            <label for="date">Date</label>
                            <input type="date" class="form-control" id="date" name="date" value="<?php echo e($appointment->date); ?>">
                         </div>
                     </div>
                      <a href="<?php echo e(route('admin.appointments.index')); ?>" class="btn btn-danger">Close &amp;&amp; Cancel</a>
                      <button type="submit" class="btn btn-primary">Submit Details</button>
                   </form>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahashon/Desktop/Projects/hms/resources/views/admin/appointment/edit.blade.php ENDPATH**/ ?>