      <!-- Favicon -->
      <link rel="shortcut icon" href="{{ asset('backend/asset/images/logo1.png') }}" />
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="{{ asset('backend/asset/css/bootstrap.min.css') }}">
      <!-- Typography CSS -->
      <link rel="stylesheet" href="{{ asset('backend/asset/css/typography.css') }}">
      <!-- Style CSS -->
      <link rel="stylesheet" href="{{ asset('backend/asset/css/style.css') }}">
      <!-- Responsive CSS -->
      <link rel="stylesheet" href="{{ asset('backend/asset/css/responsive.css') }}">
      {{-- Bootstrap data tables --}}
      <link rel="stylesheet" href="{{ asset('backend/asset/css/dataTables.bootstrap4.min.css') }}">
      {{-- Toastr css --}}
      <link rel="stylesheet" href="{{ asset('backend/asset/css/toastr.min.css') }}">


      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
